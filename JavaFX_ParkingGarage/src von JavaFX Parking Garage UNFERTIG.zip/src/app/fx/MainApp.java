package app.fx;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class MainApp extends Application{
	
	ParkingGarage parkingGarage = null;

	public static void main(String[] args) {
		
		launch(args);
		
		// Parking Garage with 3 floors and 10 spaces per floor
		
		ParkingGarage parkingGarage = new ParkingGarage(3, 10);
		
		// Vehicles
		AbstractVehicle car1 = new Car("K-AA1101");
		AbstractVehicle car2 = new Car("B-AL1234");
		AbstractVehicle moto1 = new Motorcycle("moto-198");
		AbstractVehicle moto2 = new Motorcycle("moto-271");
		
		// Parken
		parkingGarage.parkVehicle(car1);
		parkingGarage.parkVehicle(car2);
		parkingGarage.parkVehicle(moto1);
		parkingGarage.parkVehicle(moto2);
		
		// print Status
		parkingGarage.printStatus();
		
		// search for a vehicle
		String targetId = car1.getId();
		
		Optional<AbstractVehicle> foundVehicle = parkingGarage.findVehicleByIdWithAnnonymousClass(targetId);
		foundVehicle.ifPresent(v -> System.out.println("Found vehicle with ID " + targetId + ": " + v));
		
		// remove a vehicle
		parkingGarage.removeVehicle("B-AL1234");
		
		parkingGarage.printStatus();
		
		// Find all motorcycle using lambda
		System.out.println("\n--- All Motorcycle in the Parking Garage ---");
		List<AbstractVehicle> motorcycles = parkingGarage.floors.stream()
				.flatMap(floor -> floor.getSpaces().stream())
				.filter(ParkingSpace :: isOccupied)
				.map(ParkingSpace::getVehicle)
				.filter(v -> v instanceof Motorcycle)
				.collect(Collectors.toList());
		
		// mororcycles.forEach(mo -> System.out.print(mo))
		motorcycles.forEach(System.out::println); // Abkürzung von oben
	}

	@Override
	public void start(Stage stage) throws Exception {
		
		// 5. Externe Medien oder gemeinsame Fonts
		Font costumLabelFont = Font.font("Arial", FontWeight.MEDIUM, 20);
		Font customButtonFont = Font.font("Arial", FontWeight.BOLD, 15);
		
		// 4. Nodes
		
		// Label
		Label labelParkingData = new Label("Parkhaus Daten");
		Label labelVehicleData = new Label("Fahrzeug Daten");
		Label labelOperations = new Label("Operationen");
		Label labelCars = new Label("Autos");
		Label labelMotorcycles = new Label("Motorräder");
		
		Label[] myLabels = {labelParkingData, labelVehicleData, labelOperations, labelCars, labelMotorcycles}; 
		
		for(Label oneLabel : myLabels) {
			oneLabel.setFont(costumLabelFont);
		}
		
		// Button
		Button btnCreateParkingGarage = new Button("Einlegen");
		Button btnAddCar = new Button("Auto einlegen");
		Button btnAddMotorcycle = new Button("Motorrad einlegen");
		Button btnParakingGarageStatus = new Button("PH Status");
		Button btnPark = new Button("Parken");
		Button btnDriveOut = new Button("Rausfahren");
		Button btnSearch = new Button("Suchen");
		Button btnFilter = new Button("Filtern");
		
		Button[] myButtons = {btnCreateParkingGarage, btnAddCar, btnAddMotorcycle, btnParakingGarageStatus,
				btnPark, btnDriveOut, btnSearch, btnFilter};
		
		for(Button oneButton : myButtons) {
			oneButton.setFont(customButtonFont);
			oneButton.setMinWidth(200);
			oneButton.setDisable(true);
		}
		btnCreateParkingGarage.setDisable(false);
		
		// TextField
		TextField tFTotalFloors = new TextField();
		TextField tFSpacesPerFloor = new TextField();
		TextField tFAddCar = new TextField();
		TextField tFAddMotorcycle = new TextField();
		TextField tFPark = new TextField();
		TextField tFDriveOut = new TextField();
		TextField tFSearch = new TextField();
		
		TextField[] myTextFields = {tFTotalFloors, tFSpacesPerFloor, tFAddCar, tFAddMotorcycle,
				tFPark, tFDriveOut, tFSearch};
		
		for(TextField oneTextField : myTextFields) {
			oneTextField.setMinWidth(150);
			oneTextField.setDisable(true);
		}
		tFTotalFloors.setDisable(false);
		tFSpacesPerFloor.setDisable(false);
		
		// TextArea
		TextArea tAParkData = new TextArea();
		TextArea tAFilter = new TextArea();
		
		// 3. Layout Manager
		GridPane gridPane = new GridPane();
		//gridPane.setGridLinesVisible(true);
		// gridPane.setAlignment(Pos.TOP_LEFT);
		gridPane.setHgap(10);
		gridPane.setVgap(10);
		
		// 3.1 Nodes einfügen
		
		// Labels
		gridPane.add(labelParkingData, 0, 0);
		gridPane.add(labelVehicleData, 0, 2);
		gridPane.add(labelOperations, 0, 5);
		gridPane.add(labelCars, 1, 9);
		gridPane.add(labelMotorcycles, 2, 9);
		
		// Buttons
		gridPane.add(btnCreateParkingGarage, 2, 1);
		gridPane.add(btnAddCar, 1, 3);
		gridPane.add(btnAddMotorcycle, 3, 3);
		gridPane.add(btnParakingGarageStatus, 2, 5);
		gridPane.add(btnPark, 1, 6);
		gridPane.add(btnDriveOut, 1, 7);
		gridPane.add(btnSearch, 1, 8);
		gridPane.add(btnFilter, 3, 9);
		
		// TextFields
		gridPane.add(tFTotalFloors, 0, 1);
		gridPane.add(tFSpacesPerFloor, 1, 1);
		gridPane.add(tFAddCar, 0, 3);
		gridPane.add(tFAddMotorcycle, 2, 3);
		gridPane.add(tFPark, 0, 6);
		gridPane.add(tFDriveOut, 0, 7);
		gridPane.add(tFSearch, 0, 8);
		
		// TextArea
//		gridPane.add(tAParkData, 2, 6);
		gridPane.add(tAFilter, 0, 10);
		
		// 3.2 Events
		
		// --------------------------------------------------------
		
		// Parkhaus erstellen
		btnCreateParkingGarage.setOnAction(event -> {
			
			try {
				parkingGarage = new ParkingGarage(Integer.parseInt(tFTotalFloors.getText()), Integer.parseInt(tFSpacesPerFloor.getText()));
				tFTotalFloors.setText("");
				tFSpacesPerFloor.setText("");
				
				// aktiviere alle Buttons
				for(Button oneButton : myButtons) {
					oneButton.setDisable(false);
				}
				// ABER deaktivere ParkingGarage
				btnCreateParkingGarage.setDisable(true);
				
				// aktiviere alle TextFields
				for(TextField oneTextField : myTextFields) {
					oneTextField.setDisable(false);
				}
				// ABER deaktievere TotalFloor + SpacesPerFloor
				tFTotalFloors.setDisable(true);
				tFSpacesPerFloor.setDisable(true);
				
			} catch(NumberFormatException e) {
				Alert alert = new Alert(Alert.AlertType.WARNING);
		        alert.setTitle("Fehler");
		        alert.setHeaderText(null);
		        alert.setContentText("Es dürfen nur Zahlen benutzt werden!\n" + e); // Kontext kommt per Parameter
		        alert.showAndWait();
			}
			
			System.out.println("TotalFloors: " + tFTotalFloors.getText() + "\n" +
			"SpacesPerFloor: " + tFSpacesPerFloor.getText() + "\n" +
					"Erfolgreich erstellt!");
		});
		
		// --------------------------------------------------------
		
		btnAddCar.setOnAction(event -> {

			// WIR WAREN ZULETZT HIER
			parkingGarage.parkVehicle(new Car(tFAddCar.getText()));	
		});
		
		
		// 2. Scene
		Scene scene = new Scene(gridPane, 1200, 600);
		
		// 1. Stage
		stage.setScene(scene);
		stage.setTitle("Parking Garage");
		stage.show();
	}
	
	// 6. Zusätzliche Logik eigene Methoden
}
